package com.example.mype_prm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "travelApp.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
        db.execSQL("CREATE TABLE destinations (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, imageUrl TEXT)");
        db.execSQL("CREATE TABLE bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, destinationId INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS destinations");
        db.execSQL("DROP TABLE IF EXISTS bookings");
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return result;
    }

    public boolean addDestination(String name, String description, String imageUrl) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("description", description);
        values.put("imageUrl", imageUrl);
        long result = db.insert("destinations", null, values);
        db.close();
        return result != -1;
    }

    public List<Destination> getAllDestinations() {
        List<Destination> destinations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM destinations", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String imageUrl = cursor.getString(cursor.getColumnIndexOrThrow("imageUrl"));
                destinations.add(new Destination(id, name, description, imageUrl));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return destinations;
    }

    public boolean addBooking(String username, int destinationId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Lấy userId từ username
        Cursor userCursor = db.rawQuery("SELECT id FROM users WHERE username = ?", new String[]{username});
        if (userCursor.moveToFirst()) {
            int userId = userCursor.getInt(userCursor.getColumnIndexOrThrow("id"));

            // Thêm booking
            ContentValues values = new ContentValues();
            values.put("userId", userId);
            values.put("destinationId", destinationId);
            long result = db.insert("bookings", null, values);
            userCursor.close();
            db.close();
            return result != -1;
        }
        userCursor.close();
        db.close();
        return false; // Trả về false nếu không tìm thấy user
    }


    public List<Destination> getDestinationsByUsername(String username) {
        List<Destination> destinations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Lấy userId từ username
        Cursor userCursor = db.rawQuery("SELECT id FROM users WHERE username = ?", new String[]{username});
        if (userCursor.moveToFirst()) {
            int userId = userCursor.getInt(userCursor.getColumnIndexOrThrow("id"));

            // Lấy tất cả bookings của userId
            Cursor bookingCursor = db.rawQuery("SELECT * FROM bookings WHERE userId = ?", new String[]{String.valueOf(userId)});
            if (bookingCursor.moveToFirst()) {
                do {
                    int destinationId = bookingCursor.getInt(bookingCursor.getColumnIndexOrThrow("destinationId"));

                    // Lấy thông tin destination từ destinationId
                    Cursor destinationCursor = db.rawQuery("SELECT * FROM destinations WHERE id = ?", new String[]{String.valueOf(destinationId)});
                    if (destinationCursor.moveToFirst()) {
                        int id = destinationCursor.getInt(destinationCursor.getColumnIndexOrThrow("id"));
                        String name = destinationCursor.getString(destinationCursor.getColumnIndexOrThrow("name"));
                        String description = destinationCursor.getString(destinationCursor.getColumnIndexOrThrow("description"));
                        String imageUrl = destinationCursor.getString(destinationCursor.getColumnIndexOrThrow("imageUrl"));
                        destinations.add(new Destination(id, name, description, imageUrl));
                    }
                    destinationCursor.close();
                } while (bookingCursor.moveToNext());
            }
            bookingCursor.close();
        }
        userCursor.close();
        db.close();
        return destinations;
    }




    public boolean deleteBooking(int bookingId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("bookings", "id = ?", new String[]{String.valueOf(bookingId)});
        db.close();
        return result > 0;
    }
}
