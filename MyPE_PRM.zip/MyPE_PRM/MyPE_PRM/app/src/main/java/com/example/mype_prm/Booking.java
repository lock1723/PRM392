package com.example.mype_prm;

public class Booking {
    private int id;
    private int userId;
    private int destinationId;

    public Booking(int id, int userId, int destinationId) {
        this.id = id;
        this.userId = userId;
        this.destinationId = destinationId;
    }

    // Getters và Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getDestinationId() { return destinationId; }
    public void setDestinationId(int destinationId) { this.destinationId = destinationId; }
}
