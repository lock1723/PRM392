package com.example.mype_prm;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddDestinationActivity extends AppCompatActivity {
    private EditText nameEditText, descriptionEditText, imageUrlEditText;
    private Button saveButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_destination);

        nameEditText = findViewById(R.id.etDestinationName);
        descriptionEditText = findViewById(R.id.etDestinationDescription);
        imageUrlEditText = findViewById(R.id.etImageUrl);
        saveButton = findViewById(R.id.btnSave);
        databaseHelper = new DatabaseHelper(this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String description = descriptionEditText.getText().toString();
                String imageUrl = imageUrlEditText.getText().toString();

                if (name.isEmpty() || description.isEmpty() || imageUrl.isEmpty()) {
                    Toast.makeText(AddDestinationActivity.this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                } else {
                    boolean result = databaseHelper.addDestination(name, description, imageUrl);
                    if (result) {
                        Toast.makeText(AddDestinationActivity.this, "Destination added successfully!", Toast.LENGTH_SHORT).show();
                        finish(); // Đóng activity sau khi thêm
                    } else {
                        Toast.makeText(AddDestinationActivity.this, "Failed to add destination!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}

